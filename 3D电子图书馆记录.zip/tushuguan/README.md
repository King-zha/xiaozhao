# Futuristic 3D Library

A Python-based 3D library application with interactive bookshelves, robotic elements, and a futuristic neon aesthetic.

## Features

- Immersive 3D environment with dark blue/black theme and neon glowing elements
- Advanced lighting system with multiple light sources and dynamic effects
- Atmospheric fog and particle effects for enhanced depth and mood
- Interactive camera controls (rotate, pan, zoom)
- Dynamic bookshelf creation and management with glowing borders
- Enhanced ground plane with animated interactive panels
- Holographic grid overlay and energy beam effects
- Real-time environmental effects and lighting animations
- Keyboard controls for toggling visual effects

## Requirements

- Python 3.8 or higher
- OpenGL-compatible graphics card

## Installation

1. Clone or download this project
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

Run the application:
```bash
python main.py
```

### Controls

- **Left mouse drag**: Rotate camera around the scene
- **Right mouse drag**: Pan camera across the scene  
- **Mouse wheel**: Zoom in/out
- **F key**: Toggle fog effects on/off
- **E key**: Toggle atmospheric particle effects
- **+/- keys**: Increase/decrease fog density
- **ESC or close window**: Exit application

## Project Structure

```
futuristic-3d-library/
├── main.py              # Main application entry point
├── requirements.txt     # Python dependencies
├── README.md           # This file
└── .kiro/specs/        # Design specifications
```

## Development Status

✅ **Completed:**
- Core OpenGL foundation and camera controls
- Advanced lighting system with multiple light sources
- Atmospheric effects (fog, particles, energy beams)
- Enhanced ground plane with animated panels
- Bookshelf rendering with glowing borders
- Data management system for library objects

🚧 **In Progress:**
- UI control panels for interactive bookshelf creation
- Category management and labeling system
- Book texture and cover image system
- Robotic units and holographic displays
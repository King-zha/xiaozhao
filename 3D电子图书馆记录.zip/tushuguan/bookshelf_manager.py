"""
Bookshelf Manager for the Futuristic 3D Library application
Handles bookshelf creation, rendering, and management
"""

from OpenGL.GL import *
import math
import time
from typing import Dict, List, Tuple, Optional
from data_models import Bookshelf, Book

class BookshelfManager:
    """Manages bookshelf creation and rendering with enhanced effects"""
    
    def __init__(self):
        self.start_time = time.time()
        print("BookshelfManager initialized")
    
    def create_bookshelf_geometry(self, bookshelf: Bookshelf):
        """Create enhanced bookshelf geometry with glowing borders"""
        width, height, depth = bookshelf.dimensions
        
        # Main bookshelf structure
        glPushMatrix()
        glTranslatef(*bookshelf.position)
        
        # Back panel
        self._render_back_panel(width, height, depth)
        
        # Shelves (horizontal dividers)
        self._render_shelves(width, height, depth)
        
        # Side panels
        self._render_side_panels(width, height, depth)
        
        # Glowing borders
        self._render_glowing_borders(width, height, depth, bookshelf.border_color)
        
        glPopMatrix()
    
    def _render_back_panel(self, width: float, height: float, depth: float):
        """Render the back panel of the bookshelf"""
        # Set material for back panel
        glMaterialfv(GL_FRONT, GL_AMBIENT, [0.08, 0.08, 0.12, 1.0])
        glMaterialfv(GL_FRONT, GL_DIFFUSE, [0.15, 0.15, 0.25, 1.0])
        glMaterialfv(GL_FRONT, GL_SPECULAR, [0.3, 0.3, 0.5, 1.0])
        glMaterialf(GL_FRONT, GL_SHININESS, 30.0)
        
        glColor3f(0.12, 0.12, 0.2)
        
        glPushMatrix()
        glTranslatef(0, 0, -depth/2)
        glScalef(width, height, 0.05)
        self._render_cube()
        glPopMatrix()
    
    def _render_shelves(self, width: float, height: float, depth: float):
        """Render horizontal shelves"""
        shelf_count = 5
        shelf_thickness = 0.08
        
        glColor3f(0.18, 0.18, 0.3)
        
        for i in range(shelf_count + 1):
            shelf_y = -height/2 + (i * height/shelf_count)
            glPushMatrix()
            glTranslatef(0, shelf_y, -depth/4)
            glScalef(width * 0.95, shelf_thickness, depth/2)
            self._render_cube()
            glPopMatrix()
    
    def _render_side_panels(self, width: float, height: float, depth: float):
        """Render side support panels"""
        panel_thickness = 0.06
        
        glColor3f(0.15, 0.15, 0.25)
        
        # Left panel
        glPushMatrix()
        glTranslatef(-width/2, 0, -depth/4)
        glScalef(panel_thickness, height, depth/2)
        self._render_cube()
        glPopMatrix()
        
        # Right panel
        glPushMatrix()
        glTranslatef(width/2, 0, -depth/4)
        glScalef(panel_thickness, height, depth/2)
        self._render_cube()
        glPopMatrix()
    
    def _render_glowing_borders(self, width: float, height: float, depth: float, 
                               color: Tuple[float, float, float]):
        """Render animated glowing borders"""
        current_time = time.time() - self.start_time
        
        # Animate glow intensity
        glow_pulse = (math.sin(current_time * 2.0) + 1.0) * 0.5
        glow_intensity = 0.4 + glow_pulse * 0.3
        
        # Set emission for glow
        emission = [c * glow_intensity for c in color] + [1.0]
        glMaterialfv(GL_FRONT, GL_EMISSION, emission)
        glColor3f(color[0] * (0.8 + glow_intensity * 0.4), 
                 color[1] * (0.8 + glow_intensity * 0.4), 
                 color[2] * (0.8 + glow_intensity * 0.4))
        
        border_thickness = 0.04
        
        # Vertical borders
        positions = [(-width/2, 0, depth/2), (width/2, 0, depth/2)]
        for pos in positions:
            glPushMatrix()
            glTranslatef(*pos)
            glScalef(border_thickness, height + border_thickness, border_thickness)
            self._render_cube()
            glPopMatrix()
        
        # Horizontal borders
        positions = [(0, -height/2, depth/2), (0, height/2, depth/2)]
        for pos in positions:
            glPushMatrix()
            glTranslatef(*pos)
            glScalef(width + border_thickness, border_thickness, border_thickness)
            self._render_cube()
            glPopMatrix()
        
        # Corner accents
        corner_positions = [
            (-width/2, -height/2, depth/2), (width/2, -height/2, depth/2),
            (-width/2, height/2, depth/2), (width/2, height/2, depth/2)
        ]
        
        for pos in corner_positions:
            glPushMatrix()
            glTranslatef(*pos)
            glScalef(border_thickness * 2, border_thickness * 2, border_thickness * 2)
            self._render_cube()
            glPopMatrix()
        
        # Reset emission
        glMaterialfv(GL_FRONT, GL_EMISSION, [0.0, 0.0, 0.0, 1.0])
    
    def _render_cube(self):
        """Render optimized cube geometry"""
        glBegin(GL_QUADS)
        
        # Front face
        glNormal3f(0, 0, 1)
        glVertex3f(-0.5, -0.5, 0.5)
        glVertex3f(0.5, -0.5, 0.5)
        glVertex3f(0.5, 0.5, 0.5)
        glVertex3f(-0.5, 0.5, 0.5)
        
        # Back face
        glNormal3f(0, 0, -1)
        glVertex3f(-0.5, -0.5, -0.5)
        glVertex3f(-0.5, 0.5, -0.5)
        glVertex3f(0.5, 0.5, -0.5)
        glVertex3f(0.5, -0.5, -0.5)
        
        # Top face
        glNormal3f(0, 1, 0)
        glVertex3f(-0.5, 0.5, -0.5)
        glVertex3f(-0.5, 0.5, 0.5)
        glVertex3f(0.5, 0.5, 0.5)
        glVertex3f(0.5, 0.5, -0.5)
        
        # Bottom face
        glNormal3f(0, -1, 0)
        glVertex3f(-0.5, -0.5, -0.5)
        glVertex3f(0.5, -0.5, -0.5)
        glVertex3f(0.5, -0.5, 0.5)
        glVertex3f(-0.5, -0.5, 0.5)
        
        # Right face
        glNormal3f(1, 0, 0)
        glVertex3f(0.5, -0.5, -0.5)
        glVertex3f(0.5, 0.5, -0.5)
        glVertex3f(0.5, 0.5, 0.5)
        glVertex3f(0.5, -0.5, 0.5)
        
        # Left face
        glNormal3f(-1, 0, 0)
        glVertex3f(-0.5, -0.5, -0.5)
        glVertex3f(-0.5, -0.5, 0.5)
        glVertex3f(-0.5, 0.5, 0.5)
        glVertex3f(-0.5, 0.5, -0.5)
        
        glEnd()
    
    def populate_with_default_books(self, bookshelf: Bookshelf, data_manager) -> List[Book]:
        """Populate bookshelf with default books"""
        default_titles = [
            "Quantum Mechanics", "Neural Networks", "Space Colonization",
            "AI Ethics", "Robotics Design", "Cybersecurity", "Data Mining",
            "Machine Learning", "Virtual Reality", "Blockchain Tech",
            "IoT Systems", "Future Computing", "Digital Biology",
            "Nano Technology", "Energy Systems", "Climate Tech"
        ]
        
        books = []
        for i, title in enumerate(default_titles[:12]):  # Limit to 12 books
            position = data_manager.get_next_book_position_on_shelf(bookshelf.id)
            if position:
                book = Book(
                    title=title,
                    bookshelf_id=bookshelf.id,
                    position=position
                )
                books.append(book)
                data_manager.add_book(book)
        
        return books
    
    def render_book(self, book: Book):
        """Render individual book with enhanced materials"""
        glPushMatrix()
        glTranslatef(*book.position)
        
        # Book dimensions
        book_width = 0.2
        book_height = 0.32
        book_depth = 0.04
        
        # Enhanced book material
        glMaterialfv(GL_FRONT, GL_AMBIENT, [0.15, 0.1, 0.08, 1.0])
        glMaterialfv(GL_FRONT, GL_DIFFUSE, [0.6, 0.4, 0.3, 1.0])
        glMaterialfv(GL_FRONT, GL_SPECULAR, [0.3, 0.2, 0.1, 1.0])
        glMaterialf(GL_FRONT, GL_SHININESS, 20.0)
        
        # Color variation based on book ID
        hash_val = hash(book.id) % 1000
        r = 0.3 + (hash_val % 100) / 150.0
        g = 0.2 + ((hash_val // 100) % 10) / 15.0
        b = 0.4 + ((hash_val // 10) % 10) / 25.0
        glColor3f(r, g, b)
        
        # Render book spine
        glScalef(book_width, book_height, book_depth)
        self._render_cube()
        
        glPopMatrix()
"""
Data Manager for the Futuristic 3D Library application
Handles state management and data operations for all library objects
"""

from typing import Dict, List, Optional, Tuple
from data_models import Bookshelf, Book, Category, Robot, HolographicPanel

class DataManager:
    """Manages all data state for the 3D library application"""
    
    def __init__(self):
        # Storage for all library objects
        self.bookshelves: Dict[str, Bookshelf] = {}
        self.books: Dict[str, Book] = {}
        self.categories: Dict[str, Category] = {}
        self.robots: Dict[str, Robot] = {}
        self.holographic_panels: Dict[str, HolographicPanel] = {}
        
        print("DataManager initialized")
    
    # Bookshelf management
    def add_bookshelf(self, bookshelf_data: Bookshelf) -> str:
        """Add a new bookshelf to the library"""
        self.bookshelves[bookshelf_data.id] = bookshelf_data
        print(f"Added bookshelf '{bookshelf_data.id}' at position {bookshelf_data.position}")
        return bookshelf_data.id
    
    def get_bookshelf_by_id(self, bookshelf_id: str) -> Optional[Bookshelf]:
        """Retrieve a bookshelf by its ID"""
        return self.bookshelves.get(bookshelf_id)
    
    def get_all_bookshelves(self) -> List[Bookshelf]:
        """Get all bookshelves in the library"""
        return list(self.bookshelves.values())
    
    def remove_bookshelf(self, bookshelf_id: str) -> bool:
        """Remove a bookshelf and all associated books/categories"""
        if bookshelf_id in self.bookshelves:
            # Remove associated books
            books_to_remove = [book_id for book_id, book in self.books.items() 
                             if book.bookshelf_id == bookshelf_id]
            for book_id in books_to_remove:
                del self.books[book_id]
            
            # Remove associated categories
            categories_to_remove = [cat_id for cat_id, category in self.categories.items() 
                                  if category.bookshelf_id == bookshelf_id]
            for cat_id in categories_to_remove:
                del self.categories[cat_id]
            
            # Remove bookshelf
            del self.bookshelves[bookshelf_id]
            print(f"Removed bookshelf '{bookshelf_id}' and associated items")
            return True
        return False
    
    # Category management
    def add_category(self, category_data: Category) -> str:
        """Add a new category to the library"""
        self.categories[category_data.id] = category_data
        
        # Add category to associated bookshelf
        if category_data.bookshelf_id and category_data.bookshelf_id in self.bookshelves:
            bookshelf = self.bookshelves[category_data.bookshelf_id]
            if category_data.id not in bookshelf.categories:
                bookshelf.categories.append(category_data.id)
        
        print(f"Added category '{category_data.name}' with ID '{category_data.id}'")
        return category_data.id
    
    def get_categories_by_bookshelf(self, bookshelf_id: str) -> List[Category]:
        """Get all categories associated with a specific bookshelf"""
        return [category for category in self.categories.values() 
                if category.bookshelf_id == bookshelf_id]
    
    def get_all_categories(self) -> List[Category]:
        """Get all categories in the library"""
        return list(self.categories.values())
    
    def get_category_by_id(self, category_id: str) -> Optional[Category]:
        """Retrieve a category by its ID"""
        return self.categories.get(category_id)
    
    # Book management
    def add_book(self, book_data: Book) -> str:
        """Add a new book to the library"""
        self.books[book_data.id] = book_data
        
        # Add book to associated bookshelf
        if book_data.bookshelf_id and book_data.bookshelf_id in self.bookshelves:
            bookshelf = self.bookshelves[book_data.bookshelf_id]
            bookshelf.books.append(book_data)
        
        print(f"Added book '{book_data.title}' with ID '{book_data.id}'")
        return book_data.id
    
    def get_books_by_category(self, category_id: str) -> List[Book]:
        """Get all books in a specific category"""
        return [book for book in self.books.values() 
                if book.category_id == category_id]
    
    def get_books_by_bookshelf(self, bookshelf_id: str) -> List[Book]:
        """Get all books on a specific bookshelf"""
        return [book for book in self.books.values() 
                if book.bookshelf_id == bookshelf_id]
    
    def get_all_books(self) -> List[Book]:
        """Get all books in the library"""
        return list(self.books.values())
    
    def get_book_by_id(self, book_id: str) -> Optional[Book]:
        """Retrieve a book by its ID"""
        return self.books.get(book_id)
    
    # Robot management
    def add_robot(self, robot_data: Robot) -> str:
        """Add a new robot to the library"""
        self.robots[robot_data.id] = robot_data
        print(f"Added robot '{robot_data.id}' at position {robot_data.position}")
        return robot_data.id
    
    def get_all_robots(self) -> List[Robot]:
        """Get all robots in the library"""
        return list(self.robots.values())
    
    # Holographic panel management
    def add_holographic_panel(self, panel_data: HolographicPanel) -> str:
        """Add a new holographic panel to the library"""
        self.holographic_panels[panel_data.id] = panel_data
        print(f"Added holographic panel '{panel_data.id}' at position {panel_data.position}")
        return panel_data.id
    
    def get_all_holographic_panels(self) -> List[HolographicPanel]:
        """Get all holographic panels in the library"""
        return list(self.holographic_panels.values())
    
    # Utility methods
    def get_next_book_position_on_shelf(self, bookshelf_id: str) -> Optional[Tuple[float, float, float]]:
        """Calculate the next available position for a book on a bookshelf"""
        bookshelf = self.get_bookshelf_by_id(bookshelf_id)
        if not bookshelf:
            return None
        
        books_on_shelf = self.get_books_by_bookshelf(bookshelf_id)
        books_per_row = 8  # Maximum books per shelf row
        book_width = 0.3
        book_height = 0.4
        
        # Calculate position based on number of existing books
        book_index = len(books_on_shelf)
        row = book_index // books_per_row
        col = book_index % books_per_row
        
        # Calculate position relative to bookshelf
        shelf_x, shelf_y, shelf_z = bookshelf.position
        shelf_width, shelf_height, shelf_depth = bookshelf.dimensions
        
        # Position books from left to right, bottom to top
        x = shelf_x - shelf_width/2 + (col + 0.5) * (shelf_width / books_per_row)
        y = shelf_y - shelf_height/2 + (row + 0.5) * book_height
        z = shelf_z + shelf_depth/2 - 0.1  # Slightly in front of shelf back
        
        return (x, y, z)
    
    def clear_all_data(self):
        """Clear all data (useful for testing or reset)"""
        self.bookshelves.clear()
        self.books.clear()
        self.categories.clear()
        self.robots.clear()
        self.holographic_panels.clear()
        print("All data cleared")
    
    def get_library_stats(self) -> Dict[str, int]:
        """Get statistics about the current library state"""
        return {
            "bookshelves": len(self.bookshelves),
            "books": len(self.books),
            "categories": len(self.categories),
            "robots": len(self.robots),
            "holographic_panels": len(self.holographic_panels)
        }
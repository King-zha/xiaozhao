"""
Data models for the Futuristic 3D Library application
Contains dataclasses for all 3D objects and their properties
"""

from dataclasses import dataclass, field
from typing import Tuple, List, Optional
import uuid

@dataclass
class Bookshelf:
    """Data model for a bookshelf in the 3D library"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    position: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    dimensions: Tuple[float, float, float] = (4.0, 6.0, 1.0)  # width, height, depth
    border_color: Tuple[float, float, float] = (0.2, 0.8, 1.0)  # Neon blue
    categories: List[str] = field(default_factory=list)
    books: List['Book'] = field(default_factory=list)
    mesh_id: Optional[int] = None

@dataclass
class Book:
    """Data model for an individual book"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    title: str = "Untitled Book"
    category_id: Optional[str] = None
    bookshelf_id: Optional[str] = None
    cover_texture: Optional[str] = None
    position: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    mesh_id: Optional[int] = None

@dataclass
class Category:
    """Data model for book categories"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = "General"
    bookshelf_id: Optional[str] = None
    color: Tuple[float, float, float] = (0.2, 0.8, 1.0)  # Neon blue
    label_mesh_id: Optional[int] = None

@dataclass
class Robot:
    """Data model for robotic units in the library"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    position: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    track_path: List[Tuple[float, float, float]] = field(default_factory=list)
    mesh_id: Optional[int] = None
    panel_mesh_id: Optional[int] = None

@dataclass
class HolographicPanel:
    """Data model for floating holographic displays"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    position: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    size: Tuple[float, float] = (2.0, 1.5)  # width, height
    text_content: str = "Library Data"
    mesh_id: Optional[int] = None
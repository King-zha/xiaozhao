"""
Environment Manager for the Futuristic 3D Library application
Handles environmental effects, lighting, fog, and atmospheric elements
"""

from OpenGL.GL import *
from OpenGL.GLU import *
import numpy as np
import math
import time
from typing import Tuple, List

class EnvironmentManager:
    """Manages environmental effects and atmospheric lighting"""
    
    def __init__(self):
        self.start_time = time.time()
        self.fog_enabled = True
        self.atmospheric_effects = True
        
        # Lighting parameters
        self.ambient_intensity = 0.15
        self.main_light_intensity = 0.8
        self.neon_glow_intensity = 0.6
        
        # Animation parameters
        self.glow_pulse_speed = 2.0
        self.fog_density = 0.02
        
        print("EnvironmentManager initialized with futuristic atmosphere")
    
    def setup_advanced_lighting(self):
        """Set up advanced lighting system with multiple light sources"""
        glEnable(GL_LIGHTING)
        glEnable(GL_NORMALIZE)  # Normalize normals automatically
        
        # Enable multiple lights
        glEnable(GL_LIGHT0)  # Main directional light
        glEnable(GL_LIGHT1)  # Fill light
        glEnable(GL_LIGHT2)  # Accent light for neon effects
        
        # Global ambient light (very low, blue-tinted)
        global_ambient = [0.05, 0.08, 0.15, 1.0]
        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, global_ambient)
        
        # Main directional light (cool white, from above-front)
        main_ambient = [0.1, 0.12, 0.2, 1.0]
        main_diffuse = [0.7, 0.8, 1.0, 1.0]
        main_specular = [0.9, 0.95, 1.0, 1.0]
        main_position = [8.0, 15.0, 10.0, 0.0]  # Directional light
        
        glLightfv(GL_LIGHT0, GL_AMBIENT, main_ambient)
        glLightfv(GL_LIGHT0, GL_DIFFUSE, main_diffuse)
        glLightfv(GL_LIGHT0, GL_SPECULAR, main_specular)
        glLightfv(GL_LIGHT0, GL_POSITION, main_position)
        
        # Fill light (softer, from the side)
        fill_diffuse = [0.3, 0.4, 0.6, 1.0]
        fill_position = [-5.0, 8.0, -5.0, 0.0]
        
        glLightfv(GL_LIGHT1, GL_DIFFUSE, fill_diffuse)
        glLightfv(GL_LIGHT1, GL_POSITION, fill_position)
        
        # Accent light for neon glow enhancement
        accent_diffuse = [0.2, 0.6, 1.0, 1.0]  # Blue accent
        accent_position = [0.0, 5.0, 8.0, 0.0]
        
        glLightfv(GL_LIGHT2, GL_DIFFUSE, accent_diffuse)
        glLightfv(GL_LIGHT2, GL_POSITION, accent_position)
        
        # Enable color material for easy material changes
        glEnable(GL_COLOR_MATERIAL)
        glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)
        
        print("Advanced lighting system configured")
    
    def setup_fog_effects(self):
        """Set up atmospheric fog for depth and mood"""
        if not self.fog_enabled:
            return
        
        glEnable(GL_FOG)
        
        # Fog color (dark blue to match background)
        fog_color = [0.05, 0.1, 0.2, 1.0]
        glFogfv(GL_FOG_COLOR, fog_color)
        
        # Fog parameters
        glFogi(GL_FOG_MODE, GL_EXP2)  # Exponential fog
        glFogf(GL_FOG_DENSITY, self.fog_density)
        glFogf(GL_FOG_START, 10.0)
        glFogf(GL_FOG_END, 50.0)
        
        # Fog hint for quality
        glHint(GL_FOG_HINT, GL_NICEST)
        
        print("Atmospheric fog effects enabled")
    
    def update_dynamic_lighting(self):
        """Update lighting effects that change over time"""
        current_time = time.time() - self.start_time
        
        # Pulsing glow effect for accent lighting
        pulse = (math.sin(current_time * self.glow_pulse_speed) + 1.0) * 0.5
        glow_intensity = 0.3 + pulse * 0.4
        
        # Update accent light intensity
        accent_diffuse = [0.2 * glow_intensity, 0.6 * glow_intensity, 1.0 * glow_intensity, 1.0]
        glLightfv(GL_LIGHT2, GL_DIFFUSE, accent_diffuse)
        
        # Subtle main light variation
        main_variation = 0.8 + math.sin(current_time * 0.5) * 0.1
        main_diffuse = [0.7 * main_variation, 0.8 * main_variation, 1.0 * main_variation, 1.0]
        glLightfv(GL_LIGHT0, GL_DIFFUSE, main_diffuse)
    
    def render_atmospheric_particles(self):
        """Render floating particles for atmospheric effect"""
        if not self.atmospheric_effects:
            return
        
        current_time = time.time() - self.start_time
        
        # Disable lighting for particles
        glDisable(GL_LIGHTING)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE)  # Additive blending for glow
        
        # Render floating light particles
        particle_positions = [
            (3.0, 2.0, -2.0), (-4.0, 3.5, 1.0), (1.0, 4.0, -5.0),
            (-2.0, 1.5, 3.0), (5.0, 2.8, -1.0), (-1.0, 3.2, -3.0),
            (2.5, 1.8, 4.0), (-3.5, 2.5, -2.5)
        ]
        
        for i, pos in enumerate(particle_positions):
            glPushMatrix()
            
            # Animate particle position
            offset_time = current_time + i * 0.5
            float_offset = math.sin(offset_time * 0.8) * 0.3
            glTranslatef(pos[0], pos[1] + float_offset, pos[2])
            
            # Particle glow effect
            alpha = 0.3 + math.sin(offset_time * 2.0) * 0.2
            glColor4f(0.4, 0.8, 1.0, alpha)
            
            # Render small glowing sphere
            self.render_particle_sphere(0.05)
            
            glPopMatrix()
        
        # Reset blending
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glEnable(GL_LIGHTING)
    
    def render_particle_sphere(self, radius: float):
        """Render a small glowing sphere for particle effects"""
        # Simple sphere using quad strips
        slices = 8
        stacks = 6
        
        for i in range(stacks):
            lat0 = math.pi * (-0.5 + float(i) / stacks)
            z0 = radius * math.sin(lat0)
            zr0 = radius * math.cos(lat0)
            
            lat1 = math.pi * (-0.5 + float(i + 1) / stacks)
            z1 = radius * math.sin(lat1)
            zr1 = radius * math.cos(lat1)
            
            glBegin(GL_QUAD_STRIP)
            for j in range(slices + 1):
                lng = 2 * math.pi * float(j) / slices
                x = math.cos(lng)
                y = math.sin(lng)
                
                glVertex3f(x * zr0, y * zr0, z0)
                glVertex3f(x * zr1, y * zr1, z1)
            glEnd()
    
    def render_energy_beams(self):
        """Render subtle energy beams between bookshelves"""
        if not self.atmospheric_effects:
            return
        
        current_time = time.time() - self.start_time
        
        # Disable lighting for energy effects
        glDisable(GL_LIGHTING)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE)
        
        # Energy beam positions (connecting bookshelves)
        beam_connections = [
            ((-8.0, 2.0, 0.0), (0.0, 2.0, 0.0)),    # Left to center
            ((0.0, 2.0, 0.0), (8.0, 2.0, 0.0)),     # Center to right
            ((0.0, 2.0, 0.0), (0.0, 2.0, -8.0)),    # Center to back
        ]
        
        for i, (start, end) in enumerate(beam_connections):
            # Animate beam intensity
            beam_time = current_time + i * 1.0
            intensity = 0.1 + math.sin(beam_time * 3.0) * 0.05
            
            glColor4f(0.2, 0.8, 1.0, intensity)
            
            # Render beam as a line with thickness
            glLineWidth(2.0)
            glBegin(GL_LINES)
            glVertex3f(*start)
            glVertex3f(*end)
            glEnd()
        
        glLineWidth(1.0)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glEnable(GL_LIGHTING)
    
    def render_holographic_grid(self):
        """Render a subtle holographic grid on the ground"""
        if not self.atmospheric_effects:
            return
        
        current_time = time.time() - self.start_time
        
        glDisable(GL_LIGHTING)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE)
        
        # Grid parameters
        grid_size = 20
        grid_spacing = 2.0
        grid_y = -2.8
        
        # Animate grid intensity
        grid_alpha = 0.1 + math.sin(current_time * 1.5) * 0.05
        glColor4f(0.0, 0.4, 0.8, grid_alpha)
        
        glLineWidth(1.0)
        glBegin(GL_LINES)
        
        # Horizontal lines
        for i in range(-grid_size//2, grid_size//2 + 1):
            x = i * grid_spacing
            glVertex3f(x, grid_y, -grid_size * grid_spacing / 2)
            glVertex3f(x, grid_y, grid_size * grid_spacing / 2)
        
        # Vertical lines
        for i in range(-grid_size//2, grid_size//2 + 1):
            z = i * grid_spacing
            glVertex3f(-grid_size * grid_spacing / 2, grid_y, z)
            glVertex3f(grid_size * grid_spacing / 2, grid_y, z)
        
        glEnd()
        
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glEnable(GL_LIGHTING)
    
    def render_environment(self):
        """Render all environmental effects"""
        # Update dynamic lighting
        self.update_dynamic_lighting()
        
        # Render atmospheric effects
        self.render_holographic_grid()
        self.render_atmospheric_particles()
        self.render_energy_beams()
    
    def toggle_fog(self):
        """Toggle fog effects on/off"""
        self.fog_enabled = not self.fog_enabled
        try:
            if self.fog_enabled:
                glEnable(GL_FOG)
            else:
                glDisable(GL_FOG)
        except:
            # OpenGL context not available (e.g., during testing)
            pass
        print(f"Fog effects: {'enabled' if self.fog_enabled else 'disabled'}")
    
    def toggle_atmospheric_effects(self):
        """Toggle atmospheric particle effects on/off"""
        self.atmospheric_effects = not self.atmospheric_effects
        print(f"Atmospheric effects: {'enabled' if self.atmospheric_effects else 'disabled'}")
    
    def set_fog_density(self, density: float):
        """Adjust fog density"""
        self.fog_density = max(0.0, min(0.1, density))
        try:
            glFogf(GL_FOG_DENSITY, self.fog_density)
        except:
            # OpenGL context not available (e.g., during testing)
            pass
        print(f"Fog density set to: {self.fog_density}")
    
    def set_glow_intensity(self, intensity: float):
        """Adjust overall glow intensity"""
        self.neon_glow_intensity = max(0.0, min(2.0, intensity))
        print(f"Glow intensity set to: {self.neon_glow_intensity}")
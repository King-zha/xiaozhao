#!/usr/bin/env python3
"""
Futuristic 3D Library Application
A Python-based 3D library experience with interactive bookshelves and futuristic UI
"""

import pygame
import sys
from OpenGL.GL import *
from OpenGL.GLU import *
import numpy as np
from typing import Tuple, List, Optional
from dataclasses import dataclass
import math

# Import our custom managers
from data_manager import DataManager
from scene_manager import SceneManager

# Initialize Pygame and OpenGL
pygame.init()

class LibraryApp:
    """Main application controller for the 3D Library system"""
    
    def __init__(self, width: int = 1200, height: int = 800):
        self.width = width
        self.height = height
        self.running = True
        self.clock = pygame.time.Clock()
        
        # Initialize display
        pygame.display.set_mode((width, height), pygame.DOUBLEBUF | pygame.OPENGL)
        pygame.display.set_caption("Futuristic 3D Library")
        
        # Initialize OpenGL settings
        self._init_opengl()
        
        # Initialize camera
        self.camera_distance = 15.0
        self.camera_rotation_x = 20.0
        self.camera_rotation_y = 45.0
        self.camera_target = [0.0, 0.0, 0.0]
        
        # Mouse control state
        self.mouse_dragging = False
        self.mouse_last_pos = (0, 0)
        self.mouse_button = None
        
        # Initialize managers
        self.data_manager = DataManager()
        self.scene_manager = SceneManager(self.data_manager)
        
        # Create initial library setup
        self._create_initial_library()
        
        print("LibraryApp initialized successfully with managers")
    
    def _init_opengl(self):
        """Initialize OpenGL settings and viewport"""
        # Enable depth testing
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LESS)
        
        # Enable blending for transparency effects
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        
        # Set clear color to dark blue/black theme
        glClearColor(0.05, 0.1, 0.2, 1.0)  # Dark blue background
        
        # Set up perspective projection
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(45, self.width / self.height, 0.1, 100.0)
        
        # Switch to modelview matrix
        glMatrixMode(GL_MODELVIEW)
        
        print("OpenGL initialized with futuristic color scheme")
    
    def _create_initial_library(self):
        """Create initial bookshelves and library setup"""
        # Add a few default bookshelves to showcase the system
        
        # Main central bookshelf
        self.scene_manager.add_bookshelf({
            'position': (0.0, 0.0, 0.0),
            'dimensions': (6.0, 8.0, 1.2),
            'border_color': (0.2, 0.8, 1.0)
        })
        
        # Left bookshelf
        self.scene_manager.add_bookshelf({
            'position': (-8.0, 0.0, 0.0),
            'dimensions': (4.0, 6.0, 1.0),
            'border_color': (0.8, 0.2, 1.0)  # Purple glow
        })
        
        # Right bookshelf
        self.scene_manager.add_bookshelf({
            'position': (8.0, 0.0, 0.0),
            'dimensions': (4.0, 6.0, 1.0),
            'border_color': (0.2, 1.0, 0.8)  # Cyan glow
        })
        
        # Back bookshelf
        self.scene_manager.add_bookshelf({
            'position': (0.0, 0.0, -8.0),
            'dimensions': (5.0, 7.0, 1.0),
            'border_color': (1.0, 0.8, 0.2)  # Orange glow
        })
        
        print(f"Initial library created with {len(self.data_manager.get_all_bookshelves())} bookshelves")
        stats = self.data_manager.get_library_stats()
        print(f"Library stats: {stats}")
    
    def _add_random_bookshelf(self):
        """Add a new bookshelf at a random position"""
        import random
        
        # Random position
        x = random.uniform(-12, 12)
        z = random.uniform(-12, 12)
        
        # Random color
        colors = [
            (0.2, 0.8, 1.0),  # Blue
            (0.8, 0.2, 1.0),  # Purple
            (0.2, 1.0, 0.8),  # Cyan
            (1.0, 0.8, 0.2),  # Orange
            (1.0, 0.2, 0.8),  # Pink
            (0.8, 1.0, 0.2),  # Green
        ]
        
        bookshelf_id = self.scene_manager.add_bookshelf({
            'position': (x, 0.0, z),
            'dimensions': (random.uniform(3.0, 6.0), random.uniform(5.0, 8.0), 1.0),
            'border_color': random.choice(colors)
        })
        
        print(f"Added new bookshelf at ({x:.1f}, 0.0, {z:.1f})")
        stats = self.data_manager.get_library_stats()
        print(f"Total bookshelves: {stats['bookshelves']}, books: {stats['books']}")
    
    def _add_random_book(self):
        """Add a new book to a random bookshelf"""
        import random
        
        bookshelves = self.data_manager.get_all_bookshelves()
        if not bookshelves:
            print("No bookshelves available! Press 'B' to add one first.")
            return
        
        # Random book titles
        book_titles = [
            "Quantum Physics", "AI Revolution", "Space Exploration", "Cybernetics",
            "Digital Future", "Nano Technology", "Bioengineering", "Virtual Worlds",
            "Data Science", "Robotics", "Neural Networks", "Blockchain Tech",
            "Climate Solutions", "Energy Systems", "Smart Cities", "Gene Editing"
        ]
        
        bookshelf = random.choice(bookshelves)
        title = random.choice(book_titles)
        
        book_id = self.scene_manager.add_book({
            'title': title,
            'bookshelf_id': bookshelf.id
        })
        
        if book_id:
            print(f"Added book '{title}' to bookshelf")
            stats = self.data_manager.get_library_stats()
            print(f"Total books: {stats['books']}")
        else:
            print("Bookshelf is full! Try adding a new bookshelf with 'B'")
    
    def _add_random_category(self):
        """Add a new category to a random bookshelf"""
        import random
        
        bookshelves = self.data_manager.get_all_bookshelves()
        if not bookshelves:
            print("No bookshelves available! Press 'B' to add one first.")
            return
        
        # Random categories
        categories = [
            "Science Fiction", "Technology", "Physics", "Biology",
            "Computer Science", "Engineering", "Mathematics", "Chemistry",
            "Astronomy", "Medicine", "Philosophy", "History"
        ]
        
        bookshelf = random.choice(bookshelves)
        category_name = random.choice(categories)
        
        category_id = self.scene_manager.add_category({
            'name': category_name,
            'bookshelf_id': bookshelf.id
        })
        
        print(f"Added category '{category_name}' to bookshelf")
        stats = self.data_manager.get_library_stats()
        print(f"Total categories: {stats['categories']}")
    
    def handle_events(self):
        """Handle pygame events including mouse controls"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button in [1, 3]:  # Left or right mouse button
                    self.mouse_dragging = True
                    self.mouse_last_pos = event.pos
                    self.mouse_button = event.button
            
            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button in [1, 3]:
                    self.mouse_dragging = False
                    self.mouse_button = None
            
            elif event.type == pygame.MOUSEMOTION:
                if self.mouse_dragging:
                    dx = event.pos[0] - self.mouse_last_pos[0]
                    dy = event.pos[1] - self.mouse_last_pos[1]
                    
                    if self.mouse_button == 1:  # Left button - rotate
                        self.camera_rotation_y += dx * 0.5
                        self.camera_rotation_x += dy * 0.5
                        # Clamp vertical rotation
                        self.camera_rotation_x = max(-90, min(90, self.camera_rotation_x))
                    
                    elif self.mouse_button == 3:  # Right button - pan
                        # Convert screen movement to world movement
                        pan_speed = 0.01
                        self.camera_target[0] -= dx * pan_speed
                        self.camera_target[1] += dy * pan_speed
                    
                    self.mouse_last_pos = event.pos
            
            elif event.type == pygame.MOUSEWHEEL:
                # Zoom in/out
                zoom_speed = 0.5
                self.camera_distance -= event.y * zoom_speed
                self.camera_distance = max(2.0, min(50.0, self.camera_distance))
            
            elif event.type == pygame.KEYDOWN:
                # Keyboard controls for environment effects
                if event.key == pygame.K_f:
                    # Toggle fog
                    self.scene_manager.environment_manager.toggle_fog()
                elif event.key == pygame.K_e:
                    # Toggle atmospheric effects
                    self.scene_manager.environment_manager.toggle_atmospheric_effects()
                elif event.key == pygame.K_EQUALS or event.key == pygame.K_PLUS:
                    # Increase fog density
                    current_density = self.scene_manager.environment_manager.fog_density
                    self.scene_manager.environment_manager.set_fog_density(current_density + 0.005)
                elif event.key == pygame.K_MINUS:
                    # Decrease fog density
                    current_density = self.scene_manager.environment_manager.fog_density
                    self.scene_manager.environment_manager.set_fog_density(current_density - 0.005)
                elif event.key == pygame.K_b:
                    # Add a new bookshelf
                    self._add_random_bookshelf()
                elif event.key == pygame.K_n:
                    # Add a new book to random bookshelf
                    self._add_random_book()
                elif event.key == pygame.K_c:
                    # Add a category to random bookshelf
                    self._add_random_category()
    
    def update_camera(self):
        """Update camera position based on current rotation and distance"""
        glLoadIdentity()
        
        # Calculate camera position based on spherical coordinates
        rad_x = math.radians(self.camera_rotation_x)
        rad_y = math.radians(self.camera_rotation_y)
        
        cam_x = self.camera_distance * math.cos(rad_x) * math.sin(rad_y)
        cam_y = self.camera_distance * math.sin(rad_x)
        cam_z = self.camera_distance * math.cos(rad_x) * math.cos(rad_y)
        
        # Position camera looking at target
        gluLookAt(
            cam_x + self.camera_target[0], cam_y + self.camera_target[1], cam_z + self.camera_target[2],
            self.camera_target[0], self.camera_target[1], self.camera_target[2],
            0, 1, 0
        )
    

    
    def render(self):
        """Main rendering function"""
        # Clear buffers
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        
        # Update camera
        self.update_camera()
        
        # Render the complete 3D library scene
        self.scene_manager.render_scene()
        
        # Swap buffers
        pygame.display.flip()
    
    def run(self):
        """Main application loop"""
        print("Starting 3D Library application...")
        print("Controls:")
        print("  Left mouse drag: Rotate camera")
        print("  Right mouse drag: Pan camera")
        print("  Mouse wheel: Zoom in/out")
        print("  F: Toggle fog effects")
        print("  E: Toggle atmospheric effects")
        print("  +/-: Adjust fog density")
        print("  B: Add new bookshelf")
        print("  N: Add new book")
        print("  C: Add new category")
        print("  ESC or close window: Exit")
        
        while self.running:
            self.handle_events()
            self.render()
            self.clock.tick(60)  # Target 60 FPS
        
        pygame.quit()
        sys.exit()

def main():
    """Entry point for the application"""
    try:
        app = LibraryApp()
        app.run()
    except Exception as e:
        print(f"Error starting application: {e}")
        pygame.quit()
        sys.exit(1)

if __name__ == "__main__":
    main()
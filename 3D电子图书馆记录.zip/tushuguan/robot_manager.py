"""
Robot Manager for the Futuristic 3D Library application
Handles robotic units and holographic displays
"""

from OpenGL.GL import *
import math
import time
from typing import List, Tuple
from data_models import Robot, HolographicPanel

class RobotManager:
    """Manages robotic units and holographic displays"""
    
    def __init__(self):
        self.start_time = time.time()
        self.robots = []
        self.holographic_panels = []
        self._create_default_robots()
        self._create_default_holograms()
        print("RobotManager initialized with robots and holograms")
    
    def _create_default_robots(self):
        """Create default robots positioned between bookshelves"""
        robot_positions = [
            (-4.0, -1.5, 2.0),  # Between left and center
            (4.0, -1.5, 2.0),   # Between center and right
            (0.0, -1.5, -4.0),  # Between center and back
        ]
        
        for i, pos in enumerate(robot_positions):
            robot = Robot(
                position=pos,
                track_path=[
                    (pos[0] - 2, pos[1], pos[2]),
                    (pos[0] + 2, pos[1], pos[2])
                ]
            )
            self.robots.append(robot)
    
    def _create_default_holograms(self):
        """Create default holographic panels"""
        hologram_data = [
            ((2.0, 3.0, 1.0), "LIBRARY STATUS\nBooks: 48\nCategories: 4"),
            ((-3.0, 2.5, -2.0), "SYSTEM ONLINE\nRobots: 3\nScanners: Active"),
            ((1.0, 4.0, -5.0), "RECENT ACTIVITY\nBooks Added: 12\nLast Update: Now"),
        ]
        
        for pos, text in hologram_data:
            panel = HolographicPanel(
                position=pos,
                size=(1.8, 1.2),
                text_content=text
            )
            self.holographic_panels.append(panel)
    
    def render_robot(self, robot: Robot):
        """Render a robotic unit with glowing panels"""
        current_time = time.time() - self.start_time
        
        glPushMatrix()
        glTranslatef(*robot.position)
        
        # Robot body (main chassis)
        self._render_robot_body()
        
        # Robot head/scanner
        glPushMatrix()
        glTranslatef(0, 0.8, 0)
        # Animate scanner rotation
        glRotatef(current_time * 30, 0, 1, 0)
        self._render_robot_head()
        glPopMatrix()
        
        # Glowing UI panels
        self._render_robot_panels(current_time)
        
        # Track system
        self._render_robot_tracks()
        
        glPopMatrix()
    
    def _render_robot_body(self):
        """Render the main robot chassis"""
        # Set robot material (dark metallic)
        glMaterialfv(GL_FRONT, GL_AMBIENT, [0.1, 0.1, 0.12, 1.0])
        glMaterialfv(GL_FRONT, GL_DIFFUSE, [0.2, 0.2, 0.25, 1.0])
        glMaterialfv(GL_FRONT, GL_SPECULAR, [0.5, 0.5, 0.6, 1.0])
        glMaterialf(GL_FRONT, GL_SHININESS, 60.0)
        
        glColor3f(0.15, 0.15, 0.2)
        
        # Main body
        glPushMatrix()
        glScalef(0.8, 1.2, 0.6)
        self._render_cube()
        glPopMatrix()
        
        # Arms/manipulators
        for x_offset in [-0.5, 0.5]:
            glPushMatrix()
            glTranslatef(x_offset, 0.3, 0.4)
            glScalef(0.15, 0.6, 0.15)
            self._render_cube()
            glPopMatrix()
    
    def _render_robot_head(self):
        """Render robot head/scanner unit"""
        glColor3f(0.1, 0.1, 0.15)
        
        # Scanner dome
        glPushMatrix()
        glScalef(0.4, 0.3, 0.4)
        self._render_cube()
        glPopMatrix()
        
        # Scanner eye (glowing)
        glMaterialfv(GL_FRONT, GL_EMISSION, [0.0, 0.3, 0.8, 1.0])
        glColor3f(0.2, 0.6, 1.0)
        
        glPushMatrix()
        glTranslatef(0, 0, 0.25)
        glScalef(0.1, 0.1, 0.05)
        self._render_cube()
        glPopMatrix()
        
        # Reset emission
        glMaterialfv(GL_FRONT, GL_EMISSION, [0.0, 0.0, 0.0, 1.0])
    
    def _render_robot_panels(self, current_time: float):
        """Render glowing UI panels on robot"""
        # Animate panel glow
        glow_intensity = 0.4 + math.sin(current_time * 3.0) * 0.2
        
        # Set glowing material
        emission = [0.0, 0.2 * glow_intensity, 0.6 * glow_intensity, 1.0]
        glMaterialfv(GL_FRONT, GL_EMISSION, emission)
        glColor3f(0.1, 0.4 * glow_intensity, 0.8 * glow_intensity)
        
        # Side panels
        panel_positions = [(-0.45, 0.2, 0.35), (0.45, 0.2, 0.35)]
        for pos in panel_positions:
            glPushMatrix()
            glTranslatef(*pos)
            glScalef(0.25, 0.4, 0.02)
            self._render_cube()
            glPopMatrix()
        
        # Status indicators
        indicator_positions = [(-0.3, 0.5, 0.35), (0.0, 0.5, 0.35), (0.3, 0.5, 0.35)]
        for pos in indicator_positions:
            glPushMatrix()
            glTranslatef(*pos)
            glScalef(0.08, 0.08, 0.02)
            self._render_cube()
            glPopMatrix()
        
        # Reset emission
        glMaterialfv(GL_FRONT, GL_EMISSION, [0.0, 0.0, 0.0, 1.0])
    
    def _render_robot_tracks(self):
        """Render robot track system"""
        glColor3f(0.12, 0.12, 0.18)
        
        # Track base
        glPushMatrix()
        glTranslatef(0, -0.8, 0)
        glScalef(1.0, 0.2, 0.8)
        self._render_cube()
        glPopMatrix()
        
        # Track wheels
        wheel_positions = [(-0.4, -0.8, -0.3), (-0.4, -0.8, 0.3), 
                          (0.4, -0.8, -0.3), (0.4, -0.8, 0.3)]
        for pos in wheel_positions:
            glPushMatrix()
            glTranslatef(*pos)
            glScalef(0.15, 0.15, 0.1)
            self._render_cube()
            glPopMatrix()
    
    def render_holographic_panel(self, panel: HolographicPanel):
        """Render floating holographic display"""
        current_time = time.time() - self.start_time
        
        glPushMatrix()
        glTranslatef(*panel.position)
        
        # Animate floating motion
        float_offset = math.sin(current_time * 1.5) * 0.1
        glTranslatef(0, float_offset, 0)
        
        # Animate rotation
        glRotatef(math.sin(current_time * 0.8) * 5, 0, 1, 0)
        
        # Disable lighting for hologram effect
        glDisable(GL_LIGHTING)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE)
        
        # Animate transparency
        alpha = 0.6 + math.sin(current_time * 2.0) * 0.2
        
        # Main holographic panel
        glColor4f(0.2, 0.8, 1.0, alpha * 0.3)
        width, height = panel.size
        
        glBegin(GL_QUADS)
        glVertex3f(-width/2, -height/2, 0)
        glVertex3f(width/2, -height/2, 0)
        glVertex3f(width/2, height/2, 0)
        glVertex3f(-width/2, height/2, 0)
        glEnd()
        
        # Holographic border
        glColor4f(0.4, 0.9, 1.0, alpha * 0.8)
        glLineWidth(2.0)
        glBegin(GL_LINE_LOOP)
        glVertex3f(-width/2, -height/2, 0.01)
        glVertex3f(width/2, -height/2, 0.01)
        glVertex3f(width/2, height/2, 0.01)
        glVertex3f(-width/2, height/2, 0.01)
        glEnd()
        
        # Scan lines effect
        glColor4f(0.6, 1.0, 1.0, alpha * 0.4)
        glLineWidth(1.0)
        glBegin(GL_LINES)
        for i in range(8):
            y = -height/2 + (i * height/8)
            glVertex3f(-width/2, y, 0.02)
            glVertex3f(width/2, y, 0.02)
        glEnd()
        
        # Reset rendering state
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glEnable(GL_LIGHTING)
        
        glPopMatrix()
    
    def _render_cube(self):
        """Render basic cube geometry"""
        glBegin(GL_QUADS)
        
        # Front face
        glNormal3f(0, 0, 1)
        glVertex3f(-0.5, -0.5, 0.5)
        glVertex3f(0.5, -0.5, 0.5)
        glVertex3f(0.5, 0.5, 0.5)
        glVertex3f(-0.5, 0.5, 0.5)
        
        # Back face
        glNormal3f(0, 0, -1)
        glVertex3f(-0.5, -0.5, -0.5)
        glVertex3f(-0.5, 0.5, -0.5)
        glVertex3f(0.5, 0.5, -0.5)
        glVertex3f(0.5, -0.5, -0.5)
        
        # Top face
        glNormal3f(0, 1, 0)
        glVertex3f(-0.5, 0.5, -0.5)
        glVertex3f(-0.5, 0.5, 0.5)
        glVertex3f(0.5, 0.5, 0.5)
        glVertex3f(0.5, 0.5, -0.5)
        
        # Bottom face
        glNormal3f(0, -1, 0)
        glVertex3f(-0.5, -0.5, -0.5)
        glVertex3f(0.5, -0.5, -0.5)
        glVertex3f(0.5, -0.5, 0.5)
        glVertex3f(-0.5, -0.5, 0.5)
        
        # Right face
        glNormal3f(1, 0, 0)
        glVertex3f(0.5, -0.5, -0.5)
        glVertex3f(0.5, 0.5, -0.5)
        glVertex3f(0.5, 0.5, 0.5)
        glVertex3f(0.5, -0.5, 0.5)
        
        # Left face
        glNormal3f(-1, 0, 0)
        glVertex3f(-0.5, -0.5, -0.5)
        glVertex3f(-0.5, -0.5, 0.5)
        glVertex3f(-0.5, 0.5, 0.5)
        glVertex3f(-0.5, 0.5, -0.5)
        
        glEnd()
    
    def render_all_robots(self):
        """Render all robots in the scene"""
        for robot in self.robots:
            self.render_robot(robot)
    
    def render_all_holograms(self):
        """Render all holographic panels"""
        for panel in self.holographic_panels:
            self.render_holographic_panel(panel)
"""
Scene Manager for the Futuristic 3D Library application
Handles 3D scene management, rendering, and OpenGL operations
"""

from OpenGL.GL import *
from OpenGL.GLU import *
import numpy as np
import math
from typing import Dict, List, Tuple, Optional
from data_manager import DataManager
from data_models import Bookshelf, Book, Category, Robot, HolographicPanel
from environment_manager import EnvironmentManager
from bookshelf_manager import BookshelfManager
from robot_manager import RobotManager

class SceneManager:
    """Manages the 3D scene rendering and OpenGL operations"""
    
    def __init__(self, data_manager: DataManager):
        self.data_manager = data_manager
        self.mesh_counter = 0  # For generating unique mesh IDs
        
        # Initialize managers
        self.environment_manager = EnvironmentManager()
        self.bookshelf_manager = BookshelfManager()
        self.robot_manager = RobotManager()
        
        # Setup advanced lighting and environment
        self.initialize_lighting()
        self.create_environment()
        
        print("SceneManager initialized with advanced environment system")
    
    def initialize_lighting(self):
        """Set up OpenGL lighting using the environment manager"""
        self.environment_manager.setup_advanced_lighting()
        self.environment_manager.setup_fog_effects()
    
    def create_environment(self):
        """Create the basic library environment (ground, initial elements)"""
        # Environment is now managed by EnvironmentManager
        # This method can be used for any additional scene setup
        print("Environment created with advanced atmospheric system")
    
    def render_ground(self):
        """Render the reflective ground plane with interactive panels"""
        # Main ground plane with enhanced materials
        glPushMatrix()
        
        # Set enhanced material properties for reflective ground
        glMaterialfv(GL_FRONT, GL_AMBIENT, [0.08, 0.12, 0.25, 1.0])
        glMaterialfv(GL_FRONT, GL_DIFFUSE, [0.15, 0.2, 0.4, 1.0])
        glMaterialfv(GL_FRONT, GL_SPECULAR, [0.6, 0.7, 0.9, 1.0])
        glMaterialf(GL_FRONT, GL_SHININESS, 80.0)  # Higher shininess for more reflection
        
        # Render large ground plane with better reflective properties
        glColor3f(0.12, 0.18, 0.35)  # Enhanced dark blue-gray
        glBegin(GL_QUADS)
        glNormal3f(0, 1, 0)  # Normal pointing up
        glVertex3f(-25, -3, -25)  # Larger ground area
        glVertex3f(25, -3, -25)
        glVertex3f(25, -3, 25)
        glVertex3f(-25, -3, 25)
        glEnd()
        
        # Render interactive ground panels (glowing squares)
        self.render_ground_panels()
        
        glPopMatrix()
    
    def render_ground_panels(self):
        """Render glowing interactive panels on the ground with enhanced effects"""
        import time
        current_time = time.time()
        
        panel_positions = [
            (-10, -2.9, -10), (-5, -2.9, -10), (0, -2.9, -10), (5, -2.9, -10), (10, -2.9, -10),
            (-10, -2.9, -5), (10, -2.9, -5),
            (-10, -2.9, 0), (10, -2.9, 0),
            (-10, -2.9, 5), (10, -2.9, 5),
            (-10, -2.9, 10), (-5, -2.9, 10), (0, -2.9, 10), (5, -2.9, 10), (10, -2.9, 10)
        ]
        
        for i, pos in enumerate(panel_positions):
            glPushMatrix()
            glTranslatef(*pos)
            
            # Animated glow intensity
            glow_phase = current_time * 2.0 + i * 0.5
            glow_intensity = 0.3 + math.sin(glow_phase) * 0.2
            
            # Enhanced glowing material with animation
            emission_color = [0.0, 0.2 * glow_intensity, 0.8 * glow_intensity, 1.0]
            glMaterialfv(GL_FRONT, GL_EMISSION, emission_color)
            glColor3f(0.1 + 0.1 * glow_intensity, 0.4 + 0.2 * glow_intensity, 0.8 + 0.2 * glow_intensity)
            
            # Render enhanced glowing panel with border
            # Main panel
            glBegin(GL_QUADS)
            glNormal3f(0, 1, 0)
            glVertex3f(-0.8, 0.01, -0.8)
            glVertex3f(0.8, 0.01, -0.8)
            glVertex3f(0.8, 0.01, 0.8)
            glVertex3f(-0.8, 0.01, 0.8)
            glEnd()
            
            # Glowing border
            glColor3f(0.2 + 0.3 * glow_intensity, 0.6 + 0.2 * glow_intensity, 1.0)
            glLineWidth(3.0)
            glBegin(GL_LINE_LOOP)
            glVertex3f(-0.8, 0.02, -0.8)
            glVertex3f(0.8, 0.02, -0.8)
            glVertex3f(0.8, 0.02, 0.8)
            glVertex3f(-0.8, 0.02, 0.8)
            glEnd()
            glLineWidth(1.0)
            
            # Reset emission
            glMaterialfv(GL_FRONT, GL_EMISSION, [0.0, 0.0, 0.0, 1.0])
            
            glPopMatrix()
    
    def render_cube(self, size: Tuple[float, float, float] = (1.0, 1.0, 1.0)):
        """Render a basic cube with the given dimensions"""
        width, height, depth = size
        
        glBegin(GL_QUADS)
        
        # Front face
        glNormal3f(0, 0, 1)
        glVertex3f(-width/2, -height/2, depth/2)
        glVertex3f(width/2, -height/2, depth/2)
        glVertex3f(width/2, height/2, depth/2)
        glVertex3f(-width/2, height/2, depth/2)
        
        # Back face
        glNormal3f(0, 0, -1)
        glVertex3f(-width/2, -height/2, -depth/2)
        glVertex3f(-width/2, height/2, -depth/2)
        glVertex3f(width/2, height/2, -depth/2)
        glVertex3f(width/2, -height/2, -depth/2)
        
        # Top face
        glNormal3f(0, 1, 0)
        glVertex3f(-width/2, height/2, -depth/2)
        glVertex3f(-width/2, height/2, depth/2)
        glVertex3f(width/2, height/2, depth/2)
        glVertex3f(width/2, height/2, -depth/2)
        
        # Bottom face
        glNormal3f(0, -1, 0)
        glVertex3f(-width/2, -height/2, -depth/2)
        glVertex3f(width/2, -height/2, -depth/2)
        glVertex3f(width/2, -height/2, depth/2)
        glVertex3f(-width/2, -height/2, depth/2)
        
        # Right face
        glNormal3f(1, 0, 0)
        glVertex3f(width/2, -height/2, -depth/2)
        glVertex3f(width/2, height/2, -depth/2)
        glVertex3f(width/2, height/2, depth/2)
        glVertex3f(width/2, -height/2, depth/2)
        
        # Left face
        glNormal3f(-1, 0, 0)
        glVertex3f(-width/2, -height/2, -depth/2)
        glVertex3f(-width/2, -height/2, depth/2)
        glVertex3f(-width/2, height/2, depth/2)
        glVertex3f(-width/2, height/2, -depth/2)
        
        glEnd()
    
    def render_bookshelf_frame(self, bookshelf: Bookshelf):
        """Render the frame structure of a bookshelf with glowing borders"""
        glPushMatrix()
        glTranslatef(*bookshelf.position)
        
        width, height, depth = bookshelf.dimensions
        
        # Set material for bookshelf frame
        glMaterialfv(GL_FRONT, GL_AMBIENT, [0.1, 0.1, 0.1, 1.0])
        glMaterialfv(GL_FRONT, GL_DIFFUSE, [0.3, 0.3, 0.3, 1.0])
        glColor3f(0.2, 0.2, 0.2)  # Dark gray frame
        
        # Render main bookshelf structure (back panel)
        glPushMatrix()
        glScalef(width, height, 0.1)
        self.render_cube()
        glPopMatrix()
        
        # Render glowing borders
        self.render_glowing_borders(width, height, depth, bookshelf.border_color)
        
        # Render horizontal shelves
        shelf_count = 4
        for i in range(shelf_count + 1):
            shelf_y = -height/2 + (i * height/shelf_count)
            glPushMatrix()
            glTranslatef(0, shelf_y, depth/4)
            glScalef(width, 0.05, depth/2)
            self.render_cube()
            glPopMatrix()
        
        glPopMatrix()
    
    def render_glowing_borders(self, width: float, height: float, depth: float, 
                             color: Tuple[float, float, float]):
        """Render glowing borders around a bookshelf"""
        # Set emission for glow effect
        emission_color = [color[0] * 0.5, color[1] * 0.5, color[2] * 0.5, 1.0]
        glMaterialfv(GL_FRONT, GL_EMISSION, emission_color)
        glColor3f(*color)
        
        border_thickness = 0.05
        
        # Vertical borders (left and right)
        for x_offset in [-width/2, width/2]:
            glPushMatrix()
            glTranslatef(x_offset, 0, depth/2)
            glScalef(border_thickness, height, border_thickness)
            self.render_cube()
            glPopMatrix()
        
        # Horizontal borders (top and bottom)
        for y_offset in [-height/2, height/2]:
            glPushMatrix()
            glTranslatef(0, y_offset, depth/2)
            glScalef(width, border_thickness, border_thickness)
            self.render_cube()
            glPopMatrix()
        
        # Reset emission
        glMaterialfv(GL_FRONT, GL_EMISSION, [0.0, 0.0, 0.0, 1.0])
    
    def render_book(self, book: Book):
        """Render an individual book model"""
        glPushMatrix()
        glTranslatef(*book.position)
        
        # Book dimensions
        book_width = 0.25
        book_height = 0.35
        book_depth = 0.05
        
        # Set book material (will be textured later)
        glMaterialfv(GL_FRONT, GL_AMBIENT, [0.2, 0.1, 0.1, 1.0])
        glMaterialfv(GL_FRONT, GL_DIFFUSE, [0.6, 0.3, 0.2, 1.0])
        
        # Random color based on book ID for now (will be replaced with textures)
        hash_val = hash(book.id) % 1000
        r = 0.3 + (hash_val % 100) / 200.0
        g = 0.2 + ((hash_val // 100) % 10) / 20.0
        b = 0.4 + ((hash_val // 10) % 10) / 20.0
        glColor3f(r, g, b)
        
        # Render book as small box
        glScalef(book_width, book_height, book_depth)
        self.render_cube()
        
        glPopMatrix()
    
    def add_bookshelf(self, config: Dict) -> str:
        """Add a new bookshelf to the scene"""
        # Create bookshelf data model
        bookshelf = Bookshelf(
            position=config.get('position', (0.0, 0.0, 0.0)),
            dimensions=config.get('dimensions', (4.0, 6.0, 1.0)),
            border_color=config.get('border_color', (0.2, 0.8, 1.0))
        )
        
        # Assign mesh ID
        bookshelf.mesh_id = self.mesh_counter
        self.mesh_counter += 1
        
        # Add to data manager
        bookshelf_id = self.data_manager.add_bookshelf(bookshelf)
        
        # Populate with default books using BookshelfManager
        self.bookshelf_manager.populate_with_default_books(bookshelf, self.data_manager)
        
        return bookshelf_id
    
    def populate_bookshelf_with_default_books(self, bookshelf_id: str):
        """Populate a bookshelf with default placeholder books"""
        bookshelf = self.data_manager.get_bookshelf_by_id(bookshelf_id)
        if not bookshelf:
            return
        
        # Add 12 default books
        default_titles = [
            "Quantum Computing", "Neural Networks", "Space Exploration",
            "Artificial Intelligence", "Robotics", "Cybersecurity",
            "Data Science", "Machine Learning", "Virtual Reality",
            "Blockchain", "IoT Systems", "Future Tech"
        ]
        
        for i, title in enumerate(default_titles):
            position = self.data_manager.get_next_book_position_on_shelf(bookshelf_id)
            if position:
                book = Book(
                    title=title,
                    bookshelf_id=bookshelf_id,
                    position=position
                )
                book.mesh_id = self.mesh_counter
                self.mesh_counter += 1
                
                self.data_manager.add_book(book)
    
    def add_book(self, book_data: Dict) -> str:
        """Add a new book to the scene"""
        # Get position on target bookshelf
        bookshelf_id = book_data.get('bookshelf_id')
        position = self.data_manager.get_next_book_position_on_shelf(bookshelf_id)
        
        if not position:
            print(f"Cannot add book: bookshelf {bookshelf_id} not found or full")
            return ""
        
        # Create book data model
        book = Book(
            title=book_data.get('title', 'Untitled'),
            category_id=book_data.get('category_id'),
            bookshelf_id=bookshelf_id,
            cover_texture=book_data.get('cover_texture'),
            position=position
        )
        
        # Assign mesh ID
        book.mesh_id = self.mesh_counter
        self.mesh_counter += 1
        
        # Add to data manager
        return self.data_manager.add_book(book)
    
    def add_category(self, category_data: Dict) -> str:
        """Add a new category label to the scene"""
        category = Category(
            name=category_data.get('name', 'General'),
            bookshelf_id=category_data.get('bookshelf_id'),
            color=category_data.get('color', (0.2, 0.8, 1.0))
        )
        
        # Assign mesh ID for label
        category.label_mesh_id = self.mesh_counter
        self.mesh_counter += 1
        
        # Add to data manager
        return self.data_manager.add_category(category)
    
    def render_scene(self):
        """Render the complete 3D scene with enhanced environment"""
        # Render environmental effects first
        self.environment_manager.render_environment()
        
        # Render ground with enhanced effects
        self.render_ground()
        
        # Render all bookshelves using BookshelfManager
        for bookshelf in self.data_manager.get_all_bookshelves():
            self.bookshelf_manager.create_bookshelf_geometry(bookshelf)
        
        # Render all books using BookshelfManager
        for book in self.data_manager.get_all_books():
            self.bookshelf_manager.render_book(book)
        
        # Render robots and holographic panels
        self.robot_manager.render_all_robots()
        self.robot_manager.render_all_holograms()
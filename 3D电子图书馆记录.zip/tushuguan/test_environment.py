#!/usr/bin/env python3
"""
Test script for the environment system without requiring OpenGL context
"""

from environment_manager import EnvironmentManager
import time

def test_environment_manager():
    """Test the EnvironmentManager functionality"""
    print("Testing EnvironmentManager...")
    
    # Initialize environment manager
    env_manager = EnvironmentManager()
    
    # Test configuration methods
    print(f"Initial fog density: {env_manager.fog_density}")
    print(f"Initial glow intensity: {env_manager.neon_glow_intensity}")
    
    # Test fog density adjustment
    env_manager.set_fog_density(0.05)
    print(f"Fog density after adjustment: {env_manager.fog_density}")
    
    # Test glow intensity adjustment
    env_manager.set_glow_intensity(1.5)
    print(f"Glow intensity after adjustment: {env_manager.neon_glow_intensity}")
    
    # Test toggle functions
    env_manager.toggle_fog()
    print(f"Fog enabled after toggle: {env_manager.fog_enabled}")
    
    env_manager.toggle_atmospheric_effects()
    print(f"Atmospheric effects after toggle: {env_manager.atmospheric_effects}")
    
    # Test time-based calculations (simulate some time passing)
    print("\nTesting time-based effects...")
    original_time = env_manager.start_time
    
    # Simulate 2 seconds passing
    env_manager.start_time = original_time - 2.0
    
    # The update methods would normally be called during rendering
    # We can't test the actual OpenGL calls, but we can verify the logic
    print("Environment manager configured successfully!")
    
    return True

def test_integration_with_scene():
    """Test integration concepts without OpenGL"""
    print("\nTesting integration concepts...")
    
    # Simulate the integration that would happen in SceneManager
    env_manager = EnvironmentManager()
    
    # Test that all required methods exist
    required_methods = [
        'setup_advanced_lighting',
        'setup_fog_effects', 
        'update_dynamic_lighting',
        'render_environment',
        'toggle_fog',
        'toggle_atmospheric_effects'
    ]
    
    for method_name in required_methods:
        if hasattr(env_manager, method_name):
            print(f"✓ Method '{method_name}' exists")
        else:
            print(f"✗ Method '{method_name}' missing")
            return False
    
    print("All required methods are available for integration")
    return True

if __name__ == "__main__":
    try:
        test_environment_manager()
        test_integration_with_scene()
        print("\n✅ All environment tests passed!")
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
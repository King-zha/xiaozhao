#!/usr/bin/env python3
"""
Test script for the manager classes without requiring OpenGL context
"""

from data_manager import DataManager
from data_models import Bookshelf, Book, Category

def test_data_manager():
    """Test the DataManager functionality"""
    print("Testing DataManager...")
    
    # Initialize data manager
    dm = DataManager()
    
    # Test bookshelf creation
    bookshelf = Bookshelf(
        position=(0.0, 0.0, 0.0),
        dimensions=(4.0, 6.0, 1.0),
        border_color=(0.2, 0.8, 1.0)
    )
    
    bookshelf_id = dm.add_bookshelf(bookshelf)
    print(f"Created bookshelf with ID: {bookshelf_id}")
    
    # Test category creation
    category = Category(
        name="Science Fiction",
        bookshelf_id=bookshelf_id,
        color=(0.8, 0.2, 1.0)
    )
    
    category_id = dm.add_category(category)
    print(f"Created category with ID: {category_id}")
    
    # Test book creation
    book = Book(
        title="Dune",
        category_id=category_id,
        bookshelf_id=bookshelf_id
    )
    
    book_id = dm.add_book(book)
    print(f"Created book with ID: {book_id}")
    
    # Test position calculation
    position = dm.get_next_book_position_on_shelf(bookshelf_id)
    print(f"Next book position: {position}")
    
    # Test statistics
    stats = dm.get_library_stats()
    print(f"Library statistics: {stats}")
    
    print("DataManager test completed successfully!")
    return True

def test_scene_manager_logic():
    """Test SceneManager logic without OpenGL"""
    print("Testing SceneManager logic...")
    
    # We can't test the full SceneManager without OpenGL context,
    # but we can test the data flow
    dm = DataManager()
    
    # Test bookshelf configuration
    config = {
        'position': (5.0, 0.0, 0.0),
        'dimensions': (3.0, 5.0, 0.8),
        'border_color': (1.0, 0.5, 0.2)
    }
    
    # Create bookshelf manually (simulating SceneManager.add_bookshelf)
    bookshelf = Bookshelf(
        position=config['position'],
        dimensions=config['dimensions'],
        border_color=config['border_color']
    )
    
    bookshelf_id = dm.add_bookshelf(bookshelf)
    
    # Simulate adding default books
    default_titles = ["Book 1", "Book 2", "Book 3"]
    for title in default_titles:
        position = dm.get_next_book_position_on_shelf(bookshelf_id)
        if position:
            book = Book(
                title=title,
                bookshelf_id=bookshelf_id,
                position=position
            )
            dm.add_book(book)
    
    # Verify results
    books = dm.get_books_by_bookshelf(bookshelf_id)
    print(f"Added {len(books)} books to bookshelf")
    
    for book in books:
        print(f"  - {book.title} at position {book.position}")
    
    print("SceneManager logic test completed successfully!")
    return True

if __name__ == "__main__":
    try:
        test_data_manager()
        print()
        test_scene_manager_logic()
        print("\nAll tests passed!")
    except Exception as e:
        print(f"Test failed: {e}")
        import traceback
        traceback.print_exc()
import torch
import gradio as gr
from transformers import AutoModel, AutoTokenizer
from peft import PeftModel

# 加载模型（同阶段4）
BASE_MODEL = "THUDM/chatglm-6b"
LORA_MODEL = "./chatglm_lora_finetune"
tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL, trust_remote_code=True)
base_model = AutoModel.from_pretrained(
    BASE_MODEL, trust_remote_code=True, torch_dtype=torch.float16, load_in_4bit=True, device_map="auto"
)
model = PeftModel.from_pretrained(base_model, LORA_MODEL)
model.eval()

# 对话函数
def predict(message, history):
    with torch.no_grad():
        response, _ = model.chat(tokenizer, message, history=history)
    return response

# 搭建界面
with gr.Blocks() as demo:
    gr.Markdown("# Python编程助手（基于ChatGLM-6B微调）")
    chatbot = gr.Chatbot()
    msg = gr.Textbox(label="输入问题")
    clear = gr.Button("清空对话")

    # 交互逻辑
    def user_input(user_msg, history):
        return "", history + [[user_msg, None]]
    def bot_response(history):
        user_msg = history[-1][0]
        bot_msg = predict(user_msg, history[:-1])
        history[-1][1] = bot_msg
        return history

    msg.submit(user_input, [msg, chatbot], [msg, chatbot]).then(bot_response, chatbot, chatbot)
    clear.click(lambda: None, None, chatbot, queue=False)

# 启动界面（本地访问）
if __name__ == "__main__":
    demo.launch(server_name="0.0.0.0", server_port=7860)
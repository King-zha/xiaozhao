import torch
import sys
import os
# 新增：忽略量化过程的数值警告
import warnings
warnings.filterwarnings("ignore", category=RuntimeWarning)

# 强制GPU运行（必须用GTX 1660的GPU）
if not torch.cuda.is_available():
    print("❌ 未检测到GPU，请检查GTX 1660驱动")
    sys.exit(1)
device = torch.device("cuda:0")
print(f"使用设备：{device}")
torch.cuda.empty_cache()

# 本地模型路径（确保是int4量化版本）
LOCAL_MODEL_PATH = r"D:\chatglm-6b-int4-local\ZhipuAI\chatglm-6b-int4"
sys.path.append(LOCAL_MODEL_PATH)

# 导入模型组件
try:
    from configuration_chatglm import ChatGLMConfig
    from modeling_chatglm import ChatGLMForConditionalGeneration
    from tokenization_chatglm import ChatGLMTokenizer
except ImportError as e:
    print(f"❌ 导入失败: {e}")
    sys.exit(1)

# 加载分词器
tokenizer = ChatGLMTokenizer(
    vocab_file=os.path.join(LOCAL_MODEL_PATH, "ice_text.model"),
    tokenizer_config_file=os.path.join(LOCAL_MODEL_PATH, "tokenizer_config.json"),
    trust_remote_code=True
)

# 加载模型（核心：匹配int4量化模型，解决类型冲突）
model = ChatGLMForConditionalGeneration.from_pretrained(
    LOCAL_MODEL_PATH,
    trust_remote_code=True,
    device_map={"": "cuda:0"},  # 字典格式（符合ChatGLM要求）+ 字符串设备名（符合transformers要求）
    torch_dtype=torch.float32,  # 适配GTX 1660精度
    quantization_bit=4  # 必须和本地模型一致（int4）
)

model.eval()  # 评估模式（禁用训练相关操作）
model = model.to("cuda:0")
torch.cuda.empty_cache()  # 清空GPU缓存

# 仅冻结参数（注释缓冲区的梯度设置，避免整数张量冲突）
for param in model.parameters():
    param.requires_grad = False
torch.cuda.empty_cache()

# 对话函数（包裹no_grad，彻底禁用梯度）
def chat(query, history=None):
    if history is None:
        history = []
    with torch.no_grad():  # 强制禁用梯度，避免张量类型错误
        response, new_history = model.chat(tokenizer, query, history=history)
    return response, new_history

# 交互式对话
print("✅ ChatGLM-6B-int4 已启动（GTX 1660适配版）")
while True:
    user_input = input("\n你: ").strip()
    if user_input.lower() == "exit":
        break
    try:
        resp, _ = chat(user_input)
        print(f"AI: {resp}")
    except Exception as e:
        print(f"⚠️ 对话出错: {e}")
        torch.cuda.empty_cache()
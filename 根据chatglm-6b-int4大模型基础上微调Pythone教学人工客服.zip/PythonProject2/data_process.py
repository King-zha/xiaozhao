import json
import pandas as pd
from transformers import AutoTokenizer

# 加载分词器
tokenizer = AutoTokenizer.from_pretrained("THUDM/chatglm-6b", trust_remote_code=True)

# 加载原始数据
with open("python_qa.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# 格式化（拼接为模型训练的prompt-response格式）
formatted_data = []
for item in data:
    prompt = f"指令：{item['instruction']}\n回答："
    formatted_data.append({
        "prompt": prompt,
        "response": item["output"]
    })

# 保存为CSV（方便模型加载）
df = pd.DataFrame(formatted_data)
df.to_csv("python_qa_processed.csv", index=False, encoding="utf-8")
print("数据预处理完成，保存为python_qa_processed.csv")
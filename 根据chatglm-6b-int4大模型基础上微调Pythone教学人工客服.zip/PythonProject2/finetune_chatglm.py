import torch
from datasets import load_dataset
from transformers import (
    AutoModel, AutoTokenizer, TrainingArguments, Trainer, DataCollatorForSeq2Seq
)
from peft import LoraConfig, get_peft_model, TaskType

# 基础配置（适配1660）
MODEL_NAME = "THUDM/chatglm-6b"
DATA_PATH = "python_qa_processed.csv"
OUTPUT_DIR = "./chatglm_lora_finetune"  # 微调权重保存路径

# 1. 加载数据集（划分训练/验证集）
dataset = load_dataset("csv", data_files=DATA_PATH)
dataset = dataset["train"].train_test_split(test_size=0.1)  # 9:1划分

# 2. 加载模型+分词器（INT4量化）
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME, trust_remote_code=True)
model = AutoModel.from_pretrained(
    MODEL_NAME,
    trust_remote_code=True,
    torch_dtype=torch.float16,
    load_in_4bit=True,  # INT4量化
    device_map="auto"
)

# 3. 配置LoRA（核心！只训练少量参数）
lora_config = LoraConfig(
    task_type=TaskType.CAUSAL_LM,  # 自回归语言模型
    r=8,  # 秩越小，显存占用越低
    lora_alpha=32,
    target_modules=["query", "key"],  # ChatGLM的Attention层模块
    lora_dropout=0.05,
    bias="none"
)
model = get_peft_model(model, lora_config)
model.print_trainable_parameters()  # 打印可训练参数（仅0.1%左右）

# 4. 数据预处理函数（转为张量）
def process_function(examples):
    prompts = examples["prompt"]
    responses = examples["response"]
    input_ids, labels, attention_masks = [], [], []
    for p, r in zip(prompts, responses):
        # 拼接输入：prompt + response
        full_text = p + r
        # 编码（截断到256长度，适配显存）
        encode = tokenizer(
            full_text, truncation=True, max_length=256, padding="max_length"
        )
        input_ids.append(encode["input_ids"])
        # 标签：只训练response部分，prompt部分设为-100（忽略）
        prompt_len = len(tokenizer.encode(p))
        label = [-100]*prompt_len + encode["input_ids"][prompt_len:]
        labels.append(label)
        # 注意力掩码
        attention_masks.append(encode["attention_mask"])
    return {"input_ids": input_ids, "labels": labels, "attention_mask": attention_masks}

# 处理数据集
processed_dataset = dataset.map(process_function, batched=True, remove_columns=dataset["train"].column_names)

# 5. 训练参数配置（适配6G显存）
training_args = TrainingArguments(
    output_dir=OUTPUT_DIR,
    per_device_train_batch_size=1,  # 只能设1（6G显存瓶颈）
    per_device_eval_batch_size=1,
    num_train_epochs=3,  # 小数据集3轮足够
    learning_rate=2e-4,
    logging_steps=5,  # 每5步打印日志
    evaluation_strategy="epoch",  # 每个epoch评估一次
    save_strategy="epoch",
    fp16=True,  # 混合精度训练，节省显存
    gradient_accumulation_steps=4,  # 梯度累积，模拟更大批次
    load_best_model_at_end=True,
    report_to="none"  # 关闭日志工具
)

# 6. 启动训练
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=processed_dataset["train"],
    eval_dataset=processed_dataset["test"],
    data_collator=DataCollatorForSeq2Seq(tokenizer=tokenizer, model=model)
)
trainer.train()

# 保存微调后的LoRA权重
model.save_pretrained(OUTPUT_DIR)
tokenizer.save_pretrained(OUTPUT_DIR)
print("微调完成！LoRA权重保存至：", OUTPUT_DIR)
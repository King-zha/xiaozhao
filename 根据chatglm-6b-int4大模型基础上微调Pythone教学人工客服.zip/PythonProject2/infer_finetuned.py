import torch
from transformers import AutoModel, AutoTokenizer
from peft import PeftModel

# 加载基础模型+LoRA微调权重
BASE_MODEL = "THUDM/chatglm-6b"
LORA_MODEL = "./chatglm_lora_finetune"  # 微调权重路径

tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL, trust_remote_code=True)
base_model = AutoModel.from_pretrained(
    BASE_MODEL, trust_remote_code=True, torch_dtype=torch.float16, load_in_4bit=True, device_map="auto"
)
# 融合LoRA权重
model = PeftModel.from_pretrained(base_model, LORA_MODEL)
model.eval()  # 推理模式

# 测试对话
def chat(prompt):
    with torch.no_grad():  # 禁用梯度，节省显存
        response, _ = model.chat(tokenizer, prompt, history=[])
    return response

# 测试示例
test_prompts = [
    "解释Python中的列表推导式",
    "写一个Python函数计算斐波那契数列"
]
for p in test_prompts:
    print("提问：", p)
    print("回答：", chat(p))
    print("-"*50)
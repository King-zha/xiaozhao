[
    {
        "instruction": "解释Python中的列表推导式",
        "input": "",
        "output": "列表推导式是Python创建列表的简洁方式，语法：[表达式 for 变量 in 可迭代对象 if 条件]。示例：生成1-10的偶数列表：[x for x in range(1,11) if x%2==0]，结果为[2,4,6,8,10]。"
    },
    {
        "instruction": "如何解决Python的KeyError错误",
        "input": "",
        "output": "KeyError是访问字典不存在的键导致的。解决方法：1. 用dict.get(key, 默认值)；2. 先判断键是否存在；3. try-except捕获。示例：\nd = {'a':1}\nprint(d.get('b', 0)) # 返回0"
    },
    {
        "instruction": "写一个Python函数计算斐波那契数列",
        "input": "",
        "output": "def fib(n):\n    if n <= 0:\n        return []\n    elif n == 1:\n        return [0]\n    res = [0, 1]\n    for i in range(2, n):\n        res.append(res[-1] + res[-2])\n    return res\n# 测试\nprint(fib(10)) # [0,1,1,2,3,5,8,13,21,34]"
    }
]
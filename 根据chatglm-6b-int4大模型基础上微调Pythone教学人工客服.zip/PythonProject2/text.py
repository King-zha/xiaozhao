import torch
# 检查CUDA是否可用（必须返回True）
print("CUDA可用：", torch.cuda.is_available())
# 检查CUDA版本（必须是11.6）
print("CUDA版本：", torch.version.cuda)
# 检查GPU信息（1660/6G显存）
if torch.cuda.is_available():
    print("GPU型号：", torch.cuda.get_device_name(0))
    print("GPU显存：", torch.cuda.get_device_properties(0).total_memory / 1024 / 1024, "MB")